const mysql = require('mysql2');
const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');

const app = express();

app.use(express.static('public'));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/')
    },
    filename: function(req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname)
    }
});
const upload = multer({storage: storage});
app.use('/uploads', express.static('uploads'));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root99',
    database: 'controle_estoque'
});

connection.connect(function(err) {
    if (err) {
        console.error('Erro ', err);
        return;
    }
    console.log("Conexão ok");
});

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(express.urlencoded({extended: true}));

app.get("/", function(req, res) {
    res.sendFile(__dirname + "/index.html");
});

app.get("/home", function(req, res) {
    res.sendFile(__dirname + "/public/html/home.html");
});

app.post('/login', function(req, res) {
    const username = req.body.login;
    const password = req.body.senha;

    connection.query('SELECT * FROM usuario WHERE email = ? AND senha = ?', [username, password], function(error, results, fields) {
        if (error) {
            console.error('Erro ao executar a consulta: ', error);
            res.status(500).send('Erro interno ao verificar credenciais.');
            return;
        }

        if (results.length > 0) {
            res.redirect('/home');
        } else {
            res.render('login', { errorMessage: 'Credenciais inválidas.', username: username });
            return;
        }
    });
});

app.post('/alterar-senha', function(req, res) {
    const email = req.body.email;
    const novaSenha = req.body.novaSenha;

    connection.query('UPDATE usuario SET senha = ? WHERE email = ?', [novaSenha, email], function(error, results, fields) {
        if (error) {
            console.error('Erro ao alterar a senha: ', error);
            res.status(500).send('Erro interno ao alterar a senha.');
            return;
        }

        if (results.affectedRows > 0) {
            res.status(200).send('Senha alterada com sucesso.');
        } else {
            res.status(404).send('Usuário não encontrado.');
        }
    });
});

app.post('/cadastrar', upload.fields([{ name: 'imagem_produto', maxCount: 1 }, { name: 'arquivo_zip', maxCount: 1 }]), function(req, res) {
    const descricao = req.body.descricao;
    const quantidade = req.body.quantidade;
    const valorunitario = req.body.valorunitario;
    const imagem_produto = req.files.imagem_produto ? req.files.imagem_produto[0].filename : null;
    const arquivo_zip = req.files.arquivo_zip ? req.files.arquivo_zip[0].filename : null;

    const values = [descricao, quantidade, valorunitario, imagem_produto, arquivo_zip];
    const insert = "INSERT INTO produtos(descricao, quantidade_estoque, valor_unitario, imagem_produto, arquivo_zip) VALUES (?, ?, ?, ?, ?)";

    connection.query(insert, values, function(err, result) {
        if (!err) {
            console.log("Dados inseridos com sucesso!");
            res.redirect('/listar');
        } else {
            console.log("Não foi possível inserir os dados: ", err);
            res.send("Erro!");
        }
    });
});

app.get('/listar', function(req, res) {
    const listar = "SELECT * FROM produtos";

    connection.query(listar, function(err, rows) {
        if (!err) {
            console.log("Consulta realizada com sucesso!");
            res.send(`
            <html>
                <head>
                    <title>Relatório de estoque</title>
                    <style>
                        table {
                            width: 100%;
                            border-collapse: collapse;
                        }
                        table, th, td {
                            border: 1px solid black;
                        }
                        th, td {
                            padding: 15px;
                            text-align: left;
                        }
                    </style>
                </head>
                <body>
                    <h1>Relatório de estoque</h1>
                    <table>
                        <tr>
                            <th>Código</th>
                            <th>Descrição</th>
                            <th>Quantidade</th>
                            <th>Valor</th>
                            <th>Imagem</th>
                            <th>Arquivo ZIP</th>
                            <th>Ações</th>
                        </tr>
                        ${rows.map(row => `
                        <tr>
                            <td>${row.id}</td>
                            <td>${row.descricao}</td>
                            <td>${row.quantidade_estoque}</td>
                            <td>${row.valor_unitario}</td>
                            <td><img src="/uploads/${row.imagem_produto}" style="width: 48px; height: 48px"></td>
                            <td>${row.arquivo_zip ? `<a href="/uploads/${row.arquivo_zip}" download>Download ZIP</a>` : 'N/A'}</td>
                            <td>
                                <a href="/editar/${row.id}">Editar</a> |
                                <a href="/excluir/${row.id}">Excluir</a>
                            </td>
                        </tr>
                        `).join('')}
                    </table>
                </body>
            </html>
            `);
        } else {
            console.log("Erro no relatório de estoque", err);
            res.send("Erro");
        }
    });
});

app.get('/excluir/:id', function(req, res) {
    const id = req.params.id;
    const excluir = "DELETE FROM produtos WHERE id = ?";

    connection.query(excluir, [id], function(err, result) {
        if (!err) {
            console.log("Produto deletado!");
            res.redirect('/listar');
        } else {
            console.log("Erro ao deletar produto", err);
        }
    });
});

app.get('/editar/:id', function(req, res) {
    const id = req.params.id;

    connection.query('SELECT * FROM produtos WHERE id = ?', [id], function(err, results) {
        if (err) {
            console.error('Erro ao buscar produto por ID', err);
            res.status(500).send('Erro interno ao buscar produto');
            return;
        }
        if (results.length === 0) {
            console.log("Produto não encontrado");
            res.status(404).send("Produto não encontrado");
            return;
        }

        const produto = results[0];

        res.send(`
        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width-device-width, initial-scale=1.0">
            <title>Editar produto</title>
            <link rel="stylesheet" href="styles.css">
        </head>
        <body>
            <h1>Editar produto</h1>
            <form action="/editar/${id}" method="POST" enctype="multipart/form-data">
                <label for="novaDescricao">Descrição:</label>
                <input type="text" id="novaDescricao" name="novaDescricao" value="${produto.descricao}">
                <label for="quantidade">Quantidade em Estoque:</label>
                <input type="text" id="novaQuantidade" name="novaQuantidade" value="${produto.quantidade_estoque}"><br>
                <label for="valor">Valor unitário:</label>
                <input type="text" id="novoValorUnitario" name="novoValorUnitario" value="${produto.valor_unitario}"><br>
                <label for="imagemProduto">Imagem produto:</label>
                <img src="/uploads/${produto.imagem_produto}" alt="Imagem do produto" style="width: 100px;"><br>
                <label for="novaImagem">Nova Imagem</label>
                <input type="file" id="novaImagem" name="novaImagem"><br>
                <label for="novoArquivoZip">Novo Arquivo ZIP</label>
                <input type="file" id="novoArquivoZip" name="novoArquivoZip"><br>
                <button type="submit">Salvar</button>
            </form>
        </body>
        </html>`);
    });
});

app.post('/editar/:id', upload.fields([{ name: 'novaImagem', maxCount: 1 }, { name: 'novoArquivoZip', maxCount: 1 }]), function(req, res) {
    const id = req.params.id;
    const novaDescricao = req.body.novaDescricao;
    const novaQuantidade = req.body.novaQuantidade;
    const novoValorUnitario = req.body.novoValorUnitario;
    const novaImagem = req.files.novaImagem ? req.files.novaImagem[0].filename : null;
    const novoArquivoZip = req.files.novoArquivoZip ? req.files.novoArquivoZip[0].filename : null;

    const query = 'UPDATE produtos SET descricao = ?, quantidade_estoque = ?, valor_unitario = ?' + (novaImagem ? ', imagem_produto = ?' : '') + (novoArquivoZip ? ', arquivo_zip = ?' : '') + ' WHERE id = ?';
    const values = [novaDescricao, novaQuantidade, novoValorUnitario].concat(novaImagem ? [novaImagem] : []).concat(novoArquivoZip ? [novoArquivoZip, id] : [id]);

    connection.query(query, values, function(err, result) {
        if (err) {
            console.error('Erro ao atualizar produto', err);
            res.status(500).send('Erro interno ao atualizar produto');
            return;
        }
        if (result.affectedRows === 0) {
            console.log('Produto não encontrado');
            res.status(404).send('Produto não encontrado');
            return;
        }
        console.log("Produto atualizado com sucesso!");
        res.redirect('/listar');
    });
});

app.listen(8083, function() {
    console.log("Servidor rodando na url http://localhost:8083");
});
