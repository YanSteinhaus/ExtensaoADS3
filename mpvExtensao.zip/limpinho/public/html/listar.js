<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Relatório de Estoque</title>
        <link rel="stylesheet" type="text/css" href="/estilo.css">
<script src="login.js"></script>
    </head>
    <body>
    <p class="cabeçalho">Relatório de Estoque </p>
        <div id="page-container">
            <div id="content-wrap">
                <table>
                    <tr>
                        <th> Descrição </th>
                        <th> Quantidade em estoque </th>
                        <th> Valor Unitario </th>
                    </tr>
                    ${rows.map(row => `
                    <tr>
                        <td>${row.descricao}</td>
                        <td>${row.quantidade_estoque}</td>
                        <td>${row.valor_unitario}</td>
                        
                    </tr>
                    `).join('')}
                </table>
                </div>
                <footer id="footer">
                    <a href="http://localhost:8081">Voltar</a>
                </footer>
            </div>
        </body>
    </html>
 `);